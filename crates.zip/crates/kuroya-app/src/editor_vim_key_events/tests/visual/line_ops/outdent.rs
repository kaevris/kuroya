use super::*;

#[test]
fn normal_mode_visual_character_shift_comma_outdents_selected_line_span_and_repeats() {
    let mut buffer = TextBuffer::from_text(
        1,
        None,
        "    one\n    two\n    three\n    four\n    five\n    six\n".to_owned(),
    );
    buffer.set_single_cursor(buffer.line_column_to_char(0, 2));
    let mut mode = EditorVimMode::Normal;
    let mut pending = None;
    let mut last_char_find = None;
    let mut unnamed_register = None;
    let mut last_change = None;

    for (key, modifiers) in [
        (Key::V, Modifiers::NONE),
        (Key::J, Modifiers::NONE),
        (Key::J, Modifiers::NONE),
    ] {
        let result = handle_vim_editor_key_event_with_state_and_indent(
            &mut buffer,
            key,
            modifiers,
            &mut mode,
            &mut pending,
            &mut last_char_find,
            &mut unnamed_register,
            &mut last_change,
            "  ",
        );
        assert!(result.handled);
        assert!(!result.changed);
    }

    let outdent = handle_vim_editor_key_event_with_state_and_indent(
        &mut buffer,
        Key::Comma,
        Modifiers::SHIFT,
        &mut mode,
        &mut pending,
        &mut last_char_find,
        &mut unnamed_register,
        &mut last_change,
        "  ",
    );

    assert!(outdent.handled);
    assert!(outdent.changed);
    assert_eq!(outdent.suppress_text, Some('<'));
    assert_eq!(
        buffer.text(),
        "  one\n  two\n  three\n    four\n    five\n    six\n"
    );
    assert_eq!(buffer.cursor(), buffer.line_column_to_char(0, 0));
    assert!(!buffer.has_selection());
    assert_eq!(mode, EditorVimMode::Normal);
    assert!(pending.is_none());
    assert!(last_change.is_some());

    buffer.set_single_cursor(buffer.line_column_to_char(3, 2));
    let repeat = handle_vim_editor_key_event_with_state_and_indent(
        &mut buffer,
        Key::Period,
        Modifiers::NONE,
        &mut mode,
        &mut pending,
        &mut last_char_find,
        &mut unnamed_register,
        &mut last_change,
        "  ",
    );

    assert!(repeat.handled);
    assert!(repeat.changed);
    assert_eq!(
        buffer.text(),
        "  one\n  two\n  three\n  four\n  five\n  six\n"
    );
    assert_eq!(buffer.cursor(), buffer.line_column_to_char(3, 0));
    assert!(pending.is_none());
    assert!(vim_events_include_mutation(
        &[
            key_event(Key::V, Modifiers::NONE),
            key_event(Key::J, Modifiers::NONE),
            key_event(Key::J, Modifiers::NONE),
            key_event(Key::Comma, Modifiers::SHIFT),
        ],
        EditorVimMode::Normal,
        None,
    ));
}
